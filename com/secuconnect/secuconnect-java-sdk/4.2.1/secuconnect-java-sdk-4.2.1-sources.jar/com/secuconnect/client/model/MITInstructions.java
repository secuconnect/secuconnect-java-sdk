package com.secuconnect.client.model;

import com.google.gson.annotations.SerializedName;
import java.util.Objects;

/**
 * Settings for recurring payments / merchant-initiated transactions (MIT)
 */
public class MITInstructions {
  @SerializedName("type")
  protected String type = null;

  @SerializedName("standing_instruction")
  protected String standingInstruction = null;

  @SerializedName("recurring_expiry")
  protected String recurringExpiry = null;

  @SerializedName("recurring_frequency")
  protected Integer recurringFrequency = null;

  @SerializedName("cit_reference")
  protected String citReference = null;

  public MITInstructions type(String type) {
    this.type = type;
    return this;
  }

   /**
   * Instructions type:  - &#x60;\&quot;cit\&quot;&#x60; (customer-initiated transaction/CIT for initial payment) - &#x60;\&quot;mit\&quot;&#x60; (merchant-initiated transaction/MIT for subsequent payment; requires &#x60;cit_reference&#x60;)
   * @return type
  **/
  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public MITInstructions standingInstruction(String standingInstruction) {
    this.standingInstruction = standingInstruction;
    return this;
  }

   /**
   * Standing instruction type:  - &#x60;\&quot;ucof\&quot;&#x60; (unscheduled card-on-file) - &#x60;\&quot;recurring\&quot;&#x60; (fix amount and frequency; requires &#x60;recurring_frequency&#x60;)
   * @return standingInstruction
  **/
  public String getStandingInstruction() {
    return standingInstruction;
  }

  public void setStandingInstruction(String standingInstruction) {
    this.standingInstruction = standingInstruction;
  }

  public MITInstructions recurringExpiry(String recurringExpiry) {
    this.recurringExpiry = recurringExpiry;
    return this;
  }

   /**
   * Last date the network token shall be usable for merchant-initiated transactions (MIT)
   * @return recurringExpiry
  **/
  public String getRecurringExpiry() {
    return recurringExpiry;
  }

  public void setRecurringExpiry(String recurringExpiry) {
    this.recurringExpiry = recurringExpiry;
  }

  public MITInstructions recurringFrequency(Integer recurringFrequency) {
    this.recurringFrequency = recurringFrequency;
    return this;
  }

   /**
   * Frequency of recurring payments in days  Required for standing instruction type &#x60;\&quot;recurring\&quot;&#x60;
   * @return recurringFrequency
  **/
  public Integer getRecurringFrequency() {
    return recurringFrequency;
  }

  public void setRecurringFrequency(Integer recurringFrequency) {
    this.recurringFrequency = recurringFrequency;
  }

  public MITInstructions citReference(String citReference) {
    this.citReference = citReference;
    return this;
  }

   /**
   * Payment Transactions ID from the initial customer-initiated transaction (CIT)  Required for all merchant-initiated transactions (MIT)
   * @return citReference
  **/
  public String getCitReference() {
    return citReference;
  }

  public void setCitReference(String citReference) {
    this.citReference = citReference;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MITInstructions miTInstructions = (MITInstructions) o;
    return Objects.equals(this.type, miTInstructions.type) &&
        Objects.equals(this.standingInstruction, miTInstructions.standingInstruction) &&
        Objects.equals(this.recurringExpiry, miTInstructions.recurringExpiry) &&
        Objects.equals(this.recurringFrequency, miTInstructions.recurringFrequency) &&
        Objects.equals(this.citReference, miTInstructions.citReference);
  }

  @Override
  public int hashCode() {
    return Objects.hash(type, standingInstruction, recurringExpiry, recurringFrequency, citReference);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MITInstructions {\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    standingInstruction: ").append(toIndentedString(standingInstruction)).append("\n");
    sb.append("    recurringExpiry: ").append(toIndentedString(recurringExpiry)).append("\n");
    sb.append("    recurringFrequency: ").append(toIndentedString(recurringFrequency)).append("\n");
    sb.append("    citReference: ").append(toIndentedString(citReference)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

